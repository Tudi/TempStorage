import json
import pymysql
import logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

def insertDBRow(s3_name, a_hash, p_hash, meta_hash):
    logger.debug("Connecting to DB")
    
    sql = "update RegisteredImages set Ahash=" + str(a_hash) + ",PHash=" + str(p_hash) + " where id=" + str(s3_name);
    
    try:
        mydb = pymysql.connect(
            host="imaaws.com",
            user="re131324l",
            password="re156141l",
            db="imageinfo",
            connect_timeout=5
        )
        
        # check if this should be update or insert
        cursor = mydb.cursor()
        cursor.execute(sql)
        mydb.commit()
        cursor.close()
        
        mydb.close()

    except Exception as exc:
        logger.debug("DB operation error occured on sql " + sql)
        logger.debug(str(exc))

