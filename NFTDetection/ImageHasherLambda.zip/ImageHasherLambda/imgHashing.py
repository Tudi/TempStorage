import os
import PIL_local
from PIL_local import Image
import math

def GetAHash(fileName):
    try:
        img2 = Image.open(fileName)
        w, h = 8, 8
        ColorSums = [[0 for x in range(w)] for y in range(h)] 
        width, height = img2.size
        pixelsPerBitWidth = width / w
        pixelsPerBitHeight = width / h
        for y in range(0,height):
            BitY = (int)(y /  pixelsPerBitHeight)
            for x in range(0,width):
                BitX = (int)(x /  pixelsPerBitWidth)
                pixel_now = img2.getpixel((x, y))
                pixel_now_merged = pixel_now[0]+pixel_now[1]+pixel_now[2]
                ColorSums[BitY][BitX] = ColorSums[BitY][BitX] + pixel_now_merged

        totalSum = 0
        for y in range(0,w):
            for x in range(0,h):
                totalSum = totalSum + ColorSums[y][x]
                ColorSums[y][x] = ColorSums[y][x] / (3 * pixelsPerBitWidth * pixelsPerBitHeight)
        totalAvg = totalSum / (width * height * 3)

        AHashVal = 0
        for y in range(0,w):
            for x in range(0,h):
                if ColorSums[y][x] >= totalAvg:
                    AHashVal = AHashVal * 2 | 1;
                else:
                    AHashVal = AHashVal * 2 | 0;
                    
        return AHashVal
    except Exception as e: 
        print(e)
        return 0

def DCTII(in_Matrix,out_Matrix,columns,rows):
    for col in range(0,columns):
        for row in range(0,rows):
            out_Matrix[row][col] = 0;
            for col2 in range(0,columns):
                for row2 in range(0,rows):
                    mul1 = math.cos(math.pi / columns * (col2 + 1 / 2) * row)
                    mul2 = math.cos(math.pi / rows * (row2 + 1 / 2) * col)
                    out_Matrix[row][col] = out_Matrix[row][col] + in_Matrix[col2][row2] * mul1 * mul2
    
def GetPHash(fileName):
    try:
        img2 = Image.open(fileName)
        w, h = 32, 32
        ColorSums = [[0 for x in range(w)] for y in range(h)] 
        ColorSumsDCT = [[0 for x in range(w)] for y in range(h)] 
        width, height = img2.size
        pixelsPerBitWidth = width / w
        pixelsPerBitHeight = width / h
        for y in range(0,height):
            BitY = (int)(y /  pixelsPerBitHeight)
            for x in range(0,width):
                BitX = (int)(x /  pixelsPerBitWidth)
                pixel_now = img2.getpixel((x, y))
                pixel_now_merged = pixel_now[0]+pixel_now[1]+pixel_now[2]
                ColorSums[BitY][BitX] = ColorSums[BitY][BitX] + pixel_now_merged

        DCTII(ColorSums, ColorSumsDCT, w, h)
        
        totalSum = 0
        for y in range(0,w):
            for x in range(0,h):
                totalSum = totalSum + ColorSumsDCT[y][x]
        totalAvg = totalSum / (w * h)

        PHashVal = 0
        for y in range(0,8):
            for x in range(0,8):
                if ColorSumsDCT[y][x] >= totalAvg:
                    PHashVal = PHashVal * 2 | 1;
                else:
                    PHashVal = PHashVal * 2 | 0;
                    
        return PHashVal
    except Exception as e: 
        print(e)
        return 0

#AHASH = GetAHAsh("..\\page_fetcher\\images\\cryptopunks\\8300.png")
#print(AHASH)