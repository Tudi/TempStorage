import json
import urllib.parse
import boto3
import logging
import dbhandler
import imgHashing
import io
import re

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

logger.debug('Loading function')

s3 = boto3.client('s3')
s3r = boto3.resource('s3')

def lambda_handler(event, context):
    logger.debug("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    try:
        #response = s3.get_object(Bucket=bucket, Key=key)
        #contents = response['Body'].read()
        #print(contents.decode("utf-8"))
        
        logger.debug("Starting to download: " + key)
        bucket = s3r.Bucket(bucket)
        object = bucket.Object(key)
        file_stream = io.BytesIO()
        object.download_fileobj(file_stream)

        logger.debug("Finished downloading: " + key)
        
        logger.debug("Starting to AHash: " + key)
        a_hash = imgHashing.GetAHash(file_stream)
        logger.debug("Starting to PHash: " + key)
        p_hash = imgHashing.GetPHash(file_stream)
        logger.debug("Finished hashing: " + key)
            
        meta_hash = 1
        # DBKey = int(re.search(r'\d+', key).group())
        #a_hash = a_hash & 0x7FFFFFFFFFFFFFFF # because postgress does not support unsigned
        #p_hash = p_hash & 0x7FFFFFFFFFFFFFFF # because postgress does not support unsigned        
        
        logger.debug("Updating DB row id " + key + " with AHash " + str(a_hash) + " PHash " + str(p_hash) + " meta Hash " + str(meta_hash))
        #dbhandler.insertDBRow(DBKey,a_hash,p_hash,meta_hash)
        #print("CONTENT TYPE: " + response['ContentType'])
        #return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
        
    json_data = {"ResultCode": 0, "AHASH": str(a_hash), "PHASH": str(p_hash)}
    return json_data